var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___on_use___dialogue_system =
[
    [ "AddEvent", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___on_use___dialogue_system.html#a560b1add43ccd483156b77de547ea858", null ],
    [ "CheckEvents", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___on_use___dialogue_system.html#aae9535403eb9d4f673431fcd22524778", null ],
    [ "StateChanged", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_event_handler___on_use___dialogue_system.html#a5ec9f19b923ab719bd1a959bbe9c02eb", null ]
];
var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_actor =
[
    [ "Fields", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_actor.html#aab4a93b865f7427d8218f8c41a60ec59", null ],
    [ "ID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_actor.html#acfac891116374fababdc1885163d2230", null ]
];
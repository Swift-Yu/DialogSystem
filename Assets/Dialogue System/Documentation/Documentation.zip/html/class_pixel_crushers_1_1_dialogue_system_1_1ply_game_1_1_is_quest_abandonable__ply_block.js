var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_quest_abandonable__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_quest_abandonable__ply_block.html#a8824b6de7ab04c87d288415abe767c45", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_quest_abandonable__ply_block.html#a8a85cb86dba6be9cfb90f74e5cb9be06", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_quest_abandonable__ply_block.html#abd329db6b77c3270fc696e8cac95f49b", null ]
];
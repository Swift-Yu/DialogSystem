var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_sequence_end_event =
[
    [ "HandlerType", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_sequence_end_event.html#a28d5ffb5827063c024b7602c90ad98d8", null ]
];
var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_line_cancelled_event =
[
    [ "HandlerType", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_line_cancelled_event.html#a986ef7290fb49c6dc18713b59d6e1593", null ]
];
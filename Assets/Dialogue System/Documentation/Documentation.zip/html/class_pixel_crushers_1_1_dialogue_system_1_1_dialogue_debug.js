var class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug =
[
    [ "DebugLevel", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a011a61aaaa8fa5ec8874609b15e1bd54", [
      [ "None", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a011a61aaaa8fa5ec8874609b15e1bd54a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Error", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a011a61aaaa8fa5ec8874609b15e1bd54a902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "Warning", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a011a61aaaa8fa5ec8874609b15e1bd54a0eaadb4fcb48a0a0ed7bc9868be9fbaa", null ],
      [ "Info", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a011a61aaaa8fa5ec8874609b15e1bd54a4059b0251f66a18cb56f544728796875", null ]
    ] ],
    [ "Prefix", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a8377a813bda5da14970ec922708b3aa0", null ],
    [ "Level", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#a4cce410bb426c6eba5046dcc09f4458e", null ],
    [ "LogErrors", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#ab73a37dac4f5f34ce8e23decd4a05c03", null ],
    [ "LogInfo", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#aef7ea2ffda36c93cc27fcc74dd0cb097", null ],
    [ "LogWarnings", "class_pixel_crushers_1_1_dialogue_system_1_1_dialogue_debug.html#afb02fefb9611d4b23a697a4ceed2e2d7", null ]
];
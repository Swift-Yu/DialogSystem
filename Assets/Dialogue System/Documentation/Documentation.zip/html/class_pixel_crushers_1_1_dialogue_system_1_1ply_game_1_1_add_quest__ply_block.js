var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#a1196e7102d1b5a001c3306721f179d6c", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#a9f780b4099b6b8c657ab164ccc86cd15", null ],
    [ "description", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#ab1eed2eb13101425913a7bdca78b3b4c", null ],
    [ "failureDescription", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#ae582e810bbceb4ac306c8fa277fe16d3", null ],
    [ "questState", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#a1f279e7d8bfba953a693da5e2b8ada95", null ],
    [ "successDescription", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#a2f2249e82e2e930f697c10e6222329df", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_add_quest__ply_block.html#aaf2254f5d7cd1ea30eefa3ee934301b4", null ]
];
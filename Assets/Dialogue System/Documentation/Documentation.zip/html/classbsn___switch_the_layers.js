var classbsn___switch_the_layers =
[
    [ "originalEnemyTag", "classbsn___switch_the_layers.html#aec4034963a5cce0b19ec1664bf34e83d", null ],
    [ "originalHearingMask", "classbsn___switch_the_layers.html#af20a246ae51bdb2fe47fca429cc545eb", null ],
    [ "originalLayerMask", "classbsn___switch_the_layers.html#ace8fb3399cb749d6402a4b656d06d794", null ],
    [ "originalVisionMask", "classbsn___switch_the_layers.html#ae3b9e61c4f81c627af746314b7bffbcc", null ],
    [ "traitorHearingMask", "classbsn___switch_the_layers.html#ad24693ab9ee064ef320acba85c7c0f94", null ],
    [ "traitorLayerMask", "classbsn___switch_the_layers.html#a05b215790b85136c40f5f87dd842b65d", null ],
    [ "traitorVisionMask", "classbsn___switch_the_layers.html#a15c21b9d5d432bd11d4bdbbad3d2e67f", null ]
];
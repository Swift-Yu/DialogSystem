var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry__ply_block.html#a99abe5e1ca94767ae94aa9a0fcbe1891", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry__ply_block.html#a25bfcd0a8906d2c0f8c1b34730e0c1c9", null ],
    [ "entryNumber", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry__ply_block.html#aaaab483cf90f5914ff66bbe4a8466e45", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_entry__ply_block.html#a9bc236d016e8d94d8e3c09ce33193190", null ]
];
var class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls =
[
    [ "ClearSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a439eda594984fa4374933eaafef751c7", null ],
    [ "HideContinueButton", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#ac9aef92427c488c3a796f6e58668de04", null ],
    [ "SetActive", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#aa1d5a0776be51b6619691d7250e76ffc", null ],
    [ "SetSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a72991b846bed452ffb69110ed292d42b", null ],
    [ "continueButton", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a32293149806b2481a77cf14f0b9400e7", null ],
    [ "line", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#ad844e9b7c68da7027a5673e54b691945", null ],
    [ "panel", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a15e55d5d97b96a2644bfb849407618f1", null ],
    [ "portraitImage", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#aadce94b48e9e2712b85055d715a57379", null ],
    [ "portraitName", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a6febe5811e50557bd842453bc75d4d29", null ],
    [ "richTextLine", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#a84cddbcf9dbea0d45269300893627790", null ],
    [ "HasText", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_subtitle_controls.html#aae9e45359f7f41db54dedec764908817", null ]
];
var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_conversation_active__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_conversation_active__ply_block.html#a3ef177ecfb40ebee59f3f4954f6a9d40", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_is_conversation_active__ply_block.html#af59b851d0183e791f286c7fd154b7aea", null ]
];
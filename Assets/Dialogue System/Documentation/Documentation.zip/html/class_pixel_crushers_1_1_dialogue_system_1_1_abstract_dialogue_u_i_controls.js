var class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls =
[
    [ "SetActive", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls.html#a072235861ed53716995f4c0076c9f1af", null ],
    [ "ShowPanel", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls.html#a2f74746b4a62fdb820ae25bbca336330", null ],
    [ "NPCSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls.html#a1ccab4d2ee200dfef6bb9d75a4a97602", null ],
    [ "PCSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls.html#a2380ef70c399e88d433490d9cf5cf78a", null ],
    [ "ResponseMenu", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_dialogue_u_i_controls.html#a69a5a830adffd072a95b5d38f03e6142", null ]
];
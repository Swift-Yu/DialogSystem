var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_field =
[
    [ "Hint", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_field.html#aaebdecd7b40ef0eb66aed7b709ae9207", null ],
    [ "Title", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_field.html#a30787d098955bc250a1189efe8ba7e74", null ],
    [ "Type", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_field.html#a7e349db75bc18118468eff59d6778ea9", null ],
    [ "Value", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_field.html#af7885edeea6c3921cf72ffba0371e15d", null ]
];